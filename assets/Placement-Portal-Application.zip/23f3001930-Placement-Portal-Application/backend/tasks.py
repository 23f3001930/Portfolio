from celery_worker import celery_app
from email import encoders
from email.mime.base import MIMEBase
from email.mime.multipart import MIMEMultipart 
from email.mime.text import MIMEText
import smtplib 
from flask import render_template
from models import User, Company, Drive, Application
from datetime import datetime, timedelta
import csv
import os
SERVER_SMTP_HOST = 'localhost'
SERVER_SMTP_PORT = 1025
SENDER_ADDRESS='pragatichandra@gmail.com'
SENDER_PASSWORD=''

def send_email(to_address,subject,message,content="text",attachment=None):
    msg = MIMEMultipart()
    msg['To']=to_address
    msg['From']=SENDER_ADDRESS
    msg['Subject']=subject
    if content == "html":
        msg.attach(MIMEText(message,'html'))
    else:
        msg.attach(MIMEText(message, 'plain'))

    if attachment:
        with open(attachment,"rb") as a:
            part = MIMEBase("application", "octet-stream")
            part.set_payload(a.read())
        encoders.encode_base64(part)
        part.add_header("Content-Disposition", f'attachment; filename="{attachment}"')
        msg.attach(part)          

    s = smtplib.SMTP(host=SERVER_SMTP_HOST, port=SERVER_SMTP_PORT )
    s.login(SENDER_ADDRESS,SENDER_PASSWORD)
    s.send_message(msg)
    s.quit()
    return True

@celery_app.task
def send_monthly_report():
    admin = User.query.filter_by(role='admin').first()
    if not admin:
        return "No admin user found"
    total_drives = Drive.query.count()
    total_applications = Application.query.count()
    total_selected = Application.query.filter_by( status='Selected' ).count()

    html = render_template(
        'monthly_report.html',
        total_drives=total_drives,
        total_applications=total_applications,
        total_selected=total_selected)
    send_email( admin.email, "Monthly Report", html,content="html")
    return "Monthly report sent"


@celery_app.task
def send_daily_reminder():
    tomorrow = (datetime.now() + timedelta(days=1)).date()
    drives = Drive.query.all()
    students = User.query.filter_by(role='student', blacklist=False).all()
    for drive in drives:
        if drive.deadline.date() == tomorrow:
            for student in students:
                send_email( student.email, "Placement Drive Reminder", f"Dear {student.username}, the deadline for {drive.job_title} is tomorrow."  )
    return "Daily reminders sent"  

@celery_app.task
def send_interview_reminder():
    tomorrow = (datetime.now() + timedelta(days=1)).date()
    applications = Application.query.all()
    for application in applications:
        if application.interview_datetime:
            if application.interview_datetime.date() == tomorrow:
                user = User.query.get(application.user_id)
                send_email(user.email, "Interview Reminder", f"Dear {user.username}, your interview for {application.drive.job_title} is tomorrow."  )
    return "Interview reminders sent"

@celery_app.task
def export_applications_report(user_id):
    user = User.query.get(user_id)
    applications = Application.query.filter_by(user_id=user_id).all()
    filename = f"applications_{user_id}.csv"
    filename = os.path.join("static", "studentapplications", filename)
    with open(filename, "w", newline="") as file:
        writer = csv.writer(file)
        writer.writerow([
            "Student ID",
            "Company Name",
            "Drive Title",
            "Application Status",
            "Date" ])
        for app in applications:
            drive = Drive.query.get(app.drive_id)
            company = Company.query.get(drive.company_id)
            writer.writerow([
                user.id,
                company.username,
                drive.job_title,
                app.status,
                app.applied_date   ])
    
    send_email( user.email,"Placement applications report", "find your application report attached.", attachment=filename )
    return "Application report sent"   

@celery_app.task
def export_company_applications_report(company_id):
    company = Company.query.get(company_id)
    user = User.query.get(company.user_id)
    drives = Drive.query.filter_by(company_id=company_id).all()
    filename = f"company_applications_{company_id}.csv"
    filename = os.path.join("static", "companyapplications", filename)
    with open(filename, "w", newline="") as file:
        writer = csv.writer(file)
        writer.writerow([
            "Company Name",
            "Drive Title",
            "Student Name",
            "Student Email",
            "Application Status",
            "Date" ])
        for drive in drives:
            applications = Application.query.filter_by(
                drive_id=drive.id
            ).all()
            for app in applications:
                student = User.query.get(app.user_id)
                writer.writerow([
                    company.username,
                    drive.job_title,
                    student.username,
                    student.email,
                    app.status,
                    app.applied_date ])
    send_email( user.email, "Company applications report",  "Find your application report attached.",attachment=filename)
    return "Company application report sent"