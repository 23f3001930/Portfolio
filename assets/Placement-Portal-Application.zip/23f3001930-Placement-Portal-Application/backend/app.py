from flask import Flask, request, jsonify
from flask_cors import CORS
from models import db, User, Company, Drive, Application
from werkzeug.security import generate_password_hash, check_password_hash
from flask_jwt_extended import JWTManager, create_access_token, jwt_required, get_jwt_identity, get_jwt
from flask_caching import Cache
from datetime import datetime
import os
app = Flask(__name__)

app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///placement.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False  
app.config['JWT_SECRET_KEY'] = 'your_jwt_secret_key'
app.config['CACHE_TYPE'] = 'RedisCache'
app.config['CACHE_REDIS_URL'] = 'redis://localhost:6379/0'  

CORS(app)

db.init_app(app)

jwt = JWTManager(app)
   
cache = Cache(app)



@app.route('/api/register', methods=['POST'])  #student register 
def register():
    data = request.get_json()
    
    if User.query.filter_by(email=data['email']).first():  
        return jsonify({'message': 'email already exists'}), 400
    
    user = User(
        username=data['username'],
        email=data['email'],
        password=generate_password_hash(data['password']),
        role='student',
        status='Approved',
        department=data['department'],
        cgpa=data['cgpa'],
        year=data['year']  )
    db.session.add(user)
    db.session.commit()
    return jsonify({'message': 'User registered successfully'}), 200
 
@app.route('/api/login', methods=['POST'])  #student login
def login():
    data = request.get_json()
    user = User.query.filter_by(email=data['email']).first()
    if not user or not check_password_hash(user.password, data['password']):
        return jsonify({'message': 'Invalid email or password'}), 401
    if user.role != 'student':
        return jsonify({'message': 'Invalid student account'}), 401
    if user.blacklist:
        return jsonify({'message': 'Student has been blacklisted'}), 401
    access_token = create_access_token( identity=user.id, additional_claims={'role': user.role} )
    return jsonify({
        'message': 'Login successful',
        'data': {
            'username': user.username,
            'email': user.email,
            'role': user.role,
            'access_token': access_token
        }
    }), 200

@app.route('/api/company/register', methods=['POST'])   #company register
def company_register():
    data = request.get_json()
    if User.query.filter_by(email=data['email']).first():
        return jsonify({'message': 'email already exists'}), 400

    user = User(
    username=data['username'],
    email=data['email'],
    password=generate_password_hash(data['password']),
    role='company',
    status='Pending'
    )
    db.session.add(user)
    db.session.flush()   # Get user.id before commit

    # Create Company
    company = Company(
        user_id=user.id,
        username=data['username'],
        hr_contact=data['hr_contact'],
        website=data['website']  )
    db.session.add(company)
    db.session.commit()
    return jsonify({'message': 'Company registered successfully'}), 201

@app.route('/api/company/login', methods=['POST'])  #company login
def company_login():
    data = request.get_json()
    user = User.query.filter_by(email=data['email']).first()
    if not user or not check_password_hash(user.password, data['password']):
        return jsonify({'message': 'Invalid email or password'}), 401

    if user.role != 'company':
        return jsonify({'message': 'Invalid company account'}), 401
    if user.blacklist:
        return jsonify({'message': 'Company has been blacklisted'}), 401
    if user.status != 'Approved':
        return jsonify({'message': 'Admin has not approved your account yet!'}), 401
    if user and check_password_hash(user.password, data['password']):
        access_token = create_access_token(identity=user.id,additional_claims={'role': user.role})
        return jsonify({'message': 'Company login successful','data': {'username': user.username,'email': user.email,'role': user.role,'access_token': access_token}}), 200
    
@app.route('/api/admin/login', methods=['POST']) #admin login
def admin_login():
    data = request.get_json()
    user = User.query.filter_by(email=data['email']).first()
    if user and check_password_hash(user.password, data['password']) and user.role == 'admin':
        access_token = create_access_token(identity=user.id, additional_claims={'role': user.role})
        return jsonify({'message': 'Admin login successful', 'data': {'username': user.username, 'email': user.email, 'role': user.role, 'access_token': access_token}}), 200
    else:
        return jsonify({'message': 'Invalid admin account'}), 401


@app.route('/api/company/profile', methods = ['GET'])   #company dashboard
@jwt_required()
def company_profile():
    if get_jwt().get('role') != 'company':
        return jsonify({'message': 'Company access required'}), 403
    user_id = get_jwt_identity()
    company = Company.query.filter_by(user_id=user_id).first()
    if not company:
        return jsonify({'message': 'Company not found'}), 404
    return jsonify({'username': company.username,'hr_contact': company.hr_contact,'website': company.website}), 200

@app.route('/api/blacklist/student/<int:user_id>', methods=['DELETE'])  #soft delete   blacklist student 
@jwt_required()
def blacklist_student(user_id):
    if get_jwt().get('role') != 'admin':
        return jsonify({'message': 'Admin access required'}), 403

    student = User.query.get(user_id)
    if not student or student.blacklist:
        return jsonify({'message': 'Student not found'}), 404
    student.blacklist = True
    db.session.commit()

    return jsonify({'message': 'Student blacklisted successfully'}), 200
@app.route('/api/unblacklist/student/<int:user_id>', methods=['PUT'])
@jwt_required()
def unblacklist_student(user_id):
    if get_jwt().get('role') != 'admin':
        return jsonify({'message': 'Admin access required'}), 403

    student = User.query.get(user_id)
    if not student:
        return jsonify({'message': 'Student not found'}), 404

    student.blacklist = False
    db.session.commit()
    return jsonify({'message': 'Student unblacklisted successfully'}), 200

@app.route('/api/company/<int:user_id>/approve', methods=['PUT'])    #approve company login 
@jwt_required()
def approve_company(user_id):
    if get_jwt().get('role') != 'admin':
        return jsonify({'message': 'Admin access required'}), 403
    company = User.query.get(user_id)
    if not company:
        return jsonify({'message': 'Company not found'}), 404
    if company.role != 'company':
        return jsonify({'message': 'Invalid company account'}), 400
    company.status = 'Approved'
    db.session.commit()
    return jsonify({'message': 'Company approved successfully'}), 200
@app.route('/api/company/<int:user_id>/reject', methods=['PUT'])
@jwt_required()
def reject_company(user_id):
    if get_jwt().get('role') != 'admin':
        return jsonify({'message': 'Admin access required'}), 403
    company = User.query.get(user_id)
    if not company:
        return jsonify({'message': 'Company not found'}), 404
    if company.role != 'company':
        return jsonify({'message': 'Invalid company account'}), 400
    company.status = 'Rejected'
    db.session.commit()
    return jsonify({'message': 'Company rejected successfully'}), 200


@app.route('/api/blacklist/company/<int:user_id>', methods=['DELETE'])  #soft delete compnay
@jwt_required()
def blacklist_company(user_id):
    if get_jwt().get('role') != 'admin':
        return jsonify({'message': 'Admin access required'}), 403

    company = User.query.get(user_id)
    if not company or company.blacklist:   
        return jsonify({'message': 'Company not found'}), 404

    company.blacklist = True 
    db.session.commit()

    return jsonify({'message': 'Company blacklisted successfully'}), 200

@app.route('/api/unblacklist/company/<int:user_id>', methods=['PUT'])
@jwt_required()
def unblacklist_company(user_id):
    if get_jwt().get('role') != 'admin':
        return jsonify({'message': 'Admin access required'}), 403

    company = User.query.get(user_id)
    if not company:
        return jsonify({'message': 'Company not found'}), 404

    company.blacklist = False
    db.session.commit()
    return jsonify({'message': 'Company unblacklisted successfully'}), 200

@app.route('/api/blacklist/drive/<int:drive_id>', methods=['DELETE'])
@jwt_required()
def blacklist_drive(drive_id):
    if get_jwt().get('role') != 'admin':
        return jsonify({'message': 'Admin access required'}), 403
    drive = Drive.query.get(drive_id)

    if not drive or drive.blacklist:
        return jsonify({'message': 'Drive not found'}), 404
    drive.blacklist = True
    db.session.commit()
    return jsonify({'message': 'Drive blacklisted successfully'}), 200

@app.route('/api/unblacklist/drive/<int:drive_id>', methods=['PUT'])
@jwt_required()
def unblacklist_drive(drive_id):
    if get_jwt().get('role') != 'admin':
        return jsonify({'message': 'Admin access required'}), 403
    drive = Drive.query.get(drive_id)

    if not drive:
        return jsonify({'message': 'Drive not found'}), 404

    drive.blacklist = False
    db.session.commit()
    return jsonify({'message': 'Drive unblacklisted successfully'}), 200

@app.route('/api/drive/<int:drive_id>/approve', methods=['PUT'])
@jwt_required()
def approve_drive(drive_id):
    if get_jwt().get('role') != 'admin':
        return jsonify({'message': 'Admin access required'}), 403
    drive = Drive.query.get(drive_id)
    if not drive:
        return jsonify({'message': 'Drive not found'}), 404
    drive.approval = 'Approved'
    db.session.commit()
    return jsonify({'message': 'Drive approved successfully'}), 200

@app.route('/api/drive/<int:drive_id>/reject', methods=['PUT'])
@jwt_required()
def reject_drive(drive_id):
    if get_jwt().get('role') != 'admin':
        return jsonify({'message': 'Admin access required'}), 403
    drive = Drive.query.get(drive_id)
    if not drive:
        return jsonify({'message': 'Drive not found'}), 404
    drive.approval = 'Rejected'
    db.session.commit()
    return jsonify({'message': 'Drive rejected successfully'}), 200

@app.route('/api/create/drive', methods=['POST'])    #create drive by company 
@jwt_required()
def create_drive():
    if get_jwt().get('role') != 'company':
        return jsonify({'message': 'Company access required'}), 403
    data = request.get_json()
    user_id = get_jwt_identity()
    company = Company.query.filter_by(user_id=user_id).first()
    if not company:
        return jsonify({'message': 'Company not found'}), 404
    drive = Drive.query.filter_by(company_id=company.id, job_title=data['job_title'], status='Open' ).first()
    if drive:
        return jsonify({'message': 'Drive already created'}), 400
    drive = Drive(
        company_id=company.id,
        job_title=data['job_title'],
        job_description=data['job_description'],
        package=data['package'],
        location=data['location'],
        min_cgpa=data['min_cgpa'],
        eligible_department=data['eligible_department'],
        min_year=data['min_year'],
        created_at=datetime.now(),
        deadline=datetime.fromisoformat(data['deadline']),
        status='Open',
        approval='Pending'
    )
    db.session.add(drive)
    db.session.commit()

    return jsonify({'message': 'Drive created successfully'}), 201

@app.route('/api/company/drives', methods=['GET'])   #view all drives in companydashd
@jwt_required()
@cache.cached(timeout=60)
def company_drives():
    if get_jwt().get('role') != 'company':
        return jsonify({'message': 'Company access required'}), 403
    user_id = get_jwt_identity()
    company = Company.query.filter_by(user_id=user_id).first()
    drives = Drive.query.filter_by( company_id=company.id, blacklist=False ).all()
    data = []
    for drive in drives:
        data.append({
            'id': drive.id,
            'job_title': drive.job_title,
            'job_description': drive.job_description,
            'package': drive.package,
            'location': drive.location,
            'min_cgpa': drive.min_cgpa,
            'min_year': drive.min_year, 
            'eligible_department': drive.eligible_department,
            'created_at': drive.created_at,
            'deadline': drive.deadline,
            'status': drive.status,
            'approval': drive.approval
        })
    return jsonify(data), 200

@app.route('/api/update/drive/<int:drive_id>', methods=['PUT'])    #update drive 
@jwt_required()
def update_drive(drive_id):
    if get_jwt().get('role') != 'company':
        return jsonify({'message': 'Company access required'}), 403

    drive = Drive.query.get(drive_id)
    if not drive:
        return jsonify({'message': 'Drive not found'}), 404

    data = request.get_json()
    drive.job_title = data['job_title']
    drive.job_description = data['job_description']
    drive.package = data['package']
    drive.location = data['location']
    drive.min_cgpa = data['min_cgpa']
    drive.eligible_department = data['eligible_department']
    drive.deadline = datetime.fromisoformat(data['deadline'])
    db.session.commit()

    return jsonify({'message': 'Drive updated successfully'}), 200     

@app.route('/api/drive/<int:drive_id>/complete', methods=['PUT'])    #complete drive 
@jwt_required()
def complete_drive(drive_id):
    if get_jwt().get('role') != 'company':
        return jsonify({'message': 'Company access required'}), 403

    drive = Drive.query.get(drive_id)

    if not drive:
        return jsonify({'message': 'Drive not found'}), 404

    drive.status = 'Complete'
    db.session.commit()

    return jsonify({'message': 'Drive completed successfully'}), 200


@app.route('/api/drive/<int:drive_id>/applications', methods=['GET'])        #company  interview details 
@jwt_required()
def drive_applications(drive_id):
    if get_jwt().get('role') != 'company':
        return jsonify({'message': 'Company access required'}), 403
    applications = Application.query.filter_by(drive_id=drive_id).all()
    data = []
    for application in applications:
        data.append({
            'id': application.id,
            'student_name': application.user.username,
            'student_email': application.user.email,
            'department': application.user.department,
            'cgpa': application.user.cgpa,
            'year': application.user.year,
            'resume': application.user.resume,
            'status': application.status,
            'interview_datetime': application.interview_datetime,
            'meeting_link': application.meeting_link,
            'feedback': application.feedback,
            'offer_letter': application.offer_letter
        })
    return jsonify(data), 200

@app.route('/api/company/application/<int:application_id>/status', methods=['PUT'])
@jwt_required()
def update_application_status(application_id):
    if get_jwt().get('role') != 'company':
        return jsonify({'message': 'Company access required'}), 403
    data = request.get_json()
    application = Application.query.get(application_id)
    if not application:
        return jsonify({'message': 'Application not found'}), 404
    application.status = data['status']
    db.session.commit()
    return jsonify({'message': 'Application status updated successfully' }), 200

@app.route('/api/company/application/<int:application_id>/interview', methods=['PUT'])
@jwt_required()
def schedule_interview(application_id):
    if get_jwt().get('role') != 'company':
        return jsonify({'message': 'Company access required'}), 403
    application = Application.query.get(application_id)
    if not application:
        return jsonify({'message': 'Application not found'}), 404
    data = request.get_json()
    application.interview_datetime = datetime.fromisoformat( data['interview_datetime'] )
    application.meeting_link = data['meeting_link']
    application.feedback = data['feedback']
    application.status = 'Interview'
    db.session.commit()
    return jsonify({'message': 'Interview scheduled successfully'}), 200

@app.route('/api/company/application/<int:application_id>', methods=['GET'])
@jwt_required()
def get_interview(application_id):

    if get_jwt().get('role') != 'company':
        return jsonify({'message': 'Company access required'}), 403

    application = Application.query.get(application_id)

    if not application:
        return jsonify({'message': 'Application not found'}), 404

    return jsonify({
        'interview_datetime': application.interview_datetime,
        'meeting_link': application.meeting_link,
        'feedback': application.feedback,

        'student_name': application.user.username,
        'student_email': application.user.email,
        'department': application.user.department,
        'cgpa': application.user.cgpa
    }), 200

@app.route('/api/company/application/<int:application_id>/offerletter', methods=['POST'])
@jwt_required()
def upload_offer_letter(application_id):

    if get_jwt().get('role') != 'company':
        return jsonify({'message': 'Company access required'}), 403

    application = Application.query.get(application_id)

    if not application:
        return jsonify({'message': 'Application not found'}), 404
    if application.status != 'Offer':
        return jsonify({ 'message': 'Offer Letter can only be uploaded for application status is Offer.' }), 400
    offer_letter = request.files['offer_letter']
    filename = offer_letter.filename
    offer_letter.save( os.path.join('static/offerletters', filename) )
    application.offer_letter = filename
    db.session.commit()
    return jsonify({ 'message': 'Offer Letter uploaded successfully' }), 200

@app.route('/api/student/companies', methods=['GET'])
@jwt_required()
def student_companies():
    if get_jwt().get('role') != 'student':
        return jsonify({'message': 'Student access required'}), 403
    drives = Drive.query.filter_by( approval='Approved', blacklist=False, status='Open').all()
    data = []
    for drive in drives:
        data.append ({
            'id': drive.company.id,
            'username': drive.company.username,
            'job_title': drive.job_title,
            'location': drive.location
            })
    return jsonify(data), 200

@app.route('/api/student/applications', methods=['GET'])
@jwt_required()
def student_applications():
    if get_jwt().get('role') != 'student':
        return jsonify({'message': 'Student access required'}), 403
    user_id = get_jwt_identity()
    applications = Application.query.filter_by(user_id=user_id).all()
    data = []
    for application in applications:
        data.append ({
            'id': application.id,
            'job_title': application.drive.job_title,
            'company_name': application.drive.company.username,
            'applied_date': application.applied_date,
            'interview_datetime': application.interview_datetime,
            'meeting_link': application.meeting_link,
            'feedback': application.feedback,
            'status': application.status
        })
    return jsonify(data), 200

@app.route('/api/student/viewdrive/<int:company_id>', methods=['GET'])
@jwt_required()
def student_viewdrive(company_id):
    if get_jwt().get('role') != 'student':
        return jsonify({'message': 'Student access required'}), 403
    drives = Drive.query.filter_by(company_id=company_id,status='Open',approval='Approved',blacklist=False).all()
    data = []
    for drive in drives:
        data.append ({
            'id': drive.id,
            'job_title': drive.job_title,
            'job_description': drive.job_description,
            'package': drive.package,
            'location': drive.location,
            'min_cgpa': drive.min_cgpa,
            'eligible_department': drive.eligible_department,
            'created_at': drive.created_at,
            'deadline': drive.deadline,
            'status': drive.status
        })
    return jsonify(data), 200

@app.route('/api/student/apply/<int:drive_id>', methods=['POST'])
@jwt_required()
def student_apply(drive_id):
    if get_jwt().get('role') != 'student':
        return jsonify({'message': 'Student access required'}), 403
    user_id = get_jwt_identity()
    student = User.query.get(user_id)
    drive = Drive.query.get(drive_id)
    if not student.resume:
        return jsonify({
        'message': 'Please upload your resume before applying.'}), 400
    if datetime.now() > drive.deadline:
        return jsonify({'message': 'Application deadline has passed'}), 400
    if student.cgpa < drive.min_cgpa:
        return jsonify({'message': 'Minimum CGPA criteria not met'}), 400

    if student.department != drive.eligible_department:
        return jsonify({'message': 'Your department is not eligible for this drive.'}), 400
    if student.year < drive.min_year:
        return jsonify({'message': 'You are not eligible.'}), 400
    application = Application.query.filter_by(user_id=user_id,drive_id=drive_id).first()
    if application:
        return jsonify({'message': 'Already applied'}), 400
    application = Application(
        user_id=user_id,
        drive_id=drive_id,
        applied_date=datetime.now(),
        status='Applied')
    db.session.add(application)
    db.session.commit()
    return jsonify({'message': 'Successfully applied to the drive'}), 201

@app.route('/api/student/resume', methods=['POST'])
@jwt_required()
def upload_resume():
    if get_jwt().get('role') != 'student':
        return jsonify({'message': 'Student access required'}), 403
    user_id = get_jwt_identity()
    user = User.query.get(user_id)
    resume = request.files['resume']
    filename = resume.filename
    resume.save(os.path.join('static/resumes', filename))
    user.resume = filename
    db.session.commit()
    return jsonify({'message': 'Resume uploaded successfully'}), 200

@app.route('/api/student/applicationhistory', methods=['GET'])    
@jwt_required()
def application_history():
    if get_jwt().get('role') != 'student':
        return jsonify({'message': 'Student access required'}), 403
    user_id = get_jwt_identity()
    applications = Application.query.filter_by(user_id=user_id).all()
    data = []
    for application in applications:
        data.append ({
            'id': application.id,
            'company_name': application.drive.company.username,
            'job_title': application.drive.job_title,
            'package': application.drive.package,
            'location': application.drive.location,
            'status': application.status,
            'interview_datetime': application.interview_datetime,
            'meeting_link': application.meeting_link,
            'feedback': application.feedback ,
            'offer_letter': application.offer_letter
        })
    return jsonify(data), 200

@app.route('/api/get-data', methods=['GET'])  #admin table Student and Company data all
@jwt_required()
def get_data():
    users = User.query.all()
    data = []
    for user in users:
        data.append( {
            'id': user.id,
            'username': user.username,
            'email': user.email,
            'role': user.role,   
            'status':user.status,
            'blacklist': user.blacklist
            })
    return jsonify(data)

@app.route('/api/admin/drives', methods=['GET'])   #admin table drvie data all
@jwt_required()
def admin_drives():
    if get_jwt().get('role') != 'admin':
        return jsonify({'message': 'Admin access required'}), 403
    drives = Drive.query.all()
    data = []
    for drive in drives:
        data.append( {
            'id': drive.id,
            'company_name': drive.company.username,
            'job_title': drive.job_title,
            'package': drive.package,
            'location': drive.location,
            'status': drive.status,
            'created_at': drive.created_at,
            'deadline': drive.deadline,
            'approval': drive.approval,
            'blacklist': drive.blacklist
        })

    return jsonify(data), 200

@app.route('/api/admin/appliedstudents', methods=['GET'])
@jwt_required()
def admin_applied_students():
    if get_jwt().get('role') != 'admin':
        return jsonify({'message': 'Admin access required'}), 403
    applications = Application.query.all()
    data = []
    for application in applications:
        data.append({
            'id': application.id,
            'student_name': application.user.username,
            'company_name': application.drive.company.username,
            'job_title': application.drive.job_title,
            'package': application.drive.package,
            'location': application.drive.location,
            'deadline': application.drive.deadline,
            'status': application.status
        })
    return jsonify(data), 200

@app.route('/api/export/applications', methods=['GET'])
@jwt_required()
def export_applications():
    user_id = get_jwt_identity()
    from tasks import export_applications_report
    export_applications_report.delay(user_id)
    return jsonify({ 'message': 'Applications report is being generated and will be sent to your email shortly.' }), 200

@app.route('/api/export/company/applications', methods=['GET'])
@jwt_required()
def export_company_applications():
    user_id = get_jwt_identity()
    company = Company.query.filter_by(user_id=user_id).first()
    if not company:
        return jsonify({'message': 'Company not found'}), 404
    from tasks import export_company_applications_report
    export_company_applications_report.delay(company.id)
    return jsonify({ 'message': 'Company applications report is being generated and will be sent to your email shortly.'}), 200

@app.route('/api/student/profile', methods=['GET'])
@jwt_required()
def student_editprofile():
    if get_jwt().get('role') != 'student':
        return jsonify({'message': 'Student access required'}), 403
    user_id = get_jwt_identity()
    student = User.query.get(user_id)
    return jsonify({
        'username': student.username,
        'email': student.email,
        'department': student.department,
        'cgpa': student.cgpa,
        'year': student.year
    }), 200

@app.route('/api/student/editprofile', methods=['PUT'])
@jwt_required()
def student_edit_profile():
    if get_jwt().get('role') != 'student':
        return jsonify({'message': 'Student access required'}), 403
    user_id = get_jwt_identity()
    student = User.query.get(user_id)
    data = request.get_json()
    student.username = data['username']
    student.email = data['email']
    student.department = data['department']
    student.cgpa = data['cgpa']
    student.year = data['year']
    db.session.commit()
    return jsonify({'message': 'Profile updated successfully'}), 200

if __name__ == '__main__':
    with app.app_context(): 
        db.create_all()
        if not User.query.filter_by(username='admin').first():     # admin dont need regitration 
            admin = User(username='admin', email='admin@gmail.com', password=generate_password_hash('admin'), role='admin')
            db.session.add(admin)
            db.session.commit()
    app.run(debug=True)