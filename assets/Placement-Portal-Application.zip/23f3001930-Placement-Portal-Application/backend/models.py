from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
db = SQLAlchemy()

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(40), unique=True, nullable=False)
    email = db.Column(db.String(80), unique=True, nullable=False)
    password = db.Column(db.String(200), nullable=False)
    role = db.Column(db.String(20), nullable=False, default='student')    # admin, company, student
    status = db.Column(db.String(20), default='Approved')     # Pending, Approved, Rejected (used only for companies)
    department = db.Column(db.String(100))
    cgpa = db.Column(db.Float)
    year = db.Column(db.Integer)
    resume = db.Column(db.String(255))
    blacklist = db.Column(db.Boolean, default=False, nullable=False)
    applications = db.relationship('Application', backref='user', lazy=True)

class Company(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    username = db.Column(db.String(100), nullable=False)
    hr_contact = db.Column(db.String(100), nullable=False)
    website = db.Column(db.String(200))
    drives = db.relationship('Drive', backref='company', lazy=True)


class Drive(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    company_id = db.Column(db.Integer, db.ForeignKey('company.id'), nullable=False)
    job_title = db.Column(db.String(100), nullable=False)
    job_description = db.Column(db.String(500), nullable=False)
    package = db.Column(db.Float, nullable=False)
    location = db.Column(db.String(100), nullable=False)
    status = db.Column(db.String(20), default='Open', nullable=False) # Drive lifecycle   #Pending, Complete
    min_cgpa = db.Column(db.Float, nullable=False)
    eligible_department = db.Column(db.String(100), nullable=False)
    min_year = db.Column(db.Integer, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.now, nullable=False)
    deadline = db.Column(db.DateTime, nullable=False)
    approval = db.Column(db.String(20), default="Pending", nullable=False)  # Admin approval
    blacklist = db.Column(db.Boolean, default=False, nullable=False)
    applications = db.relationship('Application', backref='drive', lazy=True)
class Application(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    drive_id = db.Column(db.Integer, db.ForeignKey('drive.id'), nullable=False)
    applied_date = db.Column(db.DateTime, nullable=False)
    interview_datetime = db.Column(db.DateTime)
    meeting_link = db.Column(db.String(255))
    feedback = db.Column(db.Text)
    offer_letter = db.Column(db.String(255))
    status = db.Column(db.String(20),default='Applied',nullable=False)   # Applied, Shortlisted, Rejected, Selected

