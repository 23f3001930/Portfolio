Terminal 1

cd placement-portal-frontend    
npm install
npm run build
npm run dev


 Terminal 2

cd backend
wsl -d Ubuntu
python3 -m venv venv
source venv/bin/activate
pip install -r requirements-working.txt
python app.py

Terminal 3 (mailhog)
cd backend
wsl -d Ubuntu
sudo apt update
12345
sudo apt install -y golang-go
go install github.com/mailhog/MailHog@latest 
~/go/bin/MailHog

Terminal 4 worker
cd backend
wsl -d Ubuntu
python -m celery -A celery_worker.celery_app worker --loglevel=info


Terminal 5 beat
cd backend
wsl -d Ubuntu
python -m celery -A celery_worker.celery_app beat --loglevel=info

Terminal 6 redis wsl

sudo apt update
12345
sudo apt install -y redis-server 
redis-server


if daily has error check the date in wsl 
date

npm list bootstrap

npm install bootstrap  if not install 














# placement-portal-frontend

This template should help get you started developing with Vue 3 in Vite.

## Recommended IDE Setup

[VS Code](https://code.visualstudio.com/) + [Vue (Official)](https://marketplace.visualstudio.com/items?itemName=Vue.volar) (and disable Vetur).

## Recommended Browser Setup

- Chromium-based browsers (Chrome, Edge, Brave, etc.):
  - [Vue.js devtools](https://chromewebstore.google.com/detail/vuejs-devtools/nhdogjmejiglipccpnnnanhbledajbpd)
  - [Turn on Custom Object Formatter in Chrome DevTools](http://bit.ly/object-formatters)
- Firefox:
  - [Vue.js devtools](https://addons.mozilla.org/en-US/firefox/addon/vue-js-devtools/)
  - [Turn on Custom Object Formatter in Firefox DevTools](https://fxdx.dev/firefox-devtools-custom-object-formatters/)

## Customize configuration

See [Vite Configuration Reference](https://vite.dev/config/).

## Project Setup

```sh
npm install
```

### Compile and Hot-Reload for Development

```sh
npm run dev
```

### Compile and Minify for Production

```sh
npm run build
```

### Lint with [ESLint](https://eslint.org/)

```sh
npm run lint
```
