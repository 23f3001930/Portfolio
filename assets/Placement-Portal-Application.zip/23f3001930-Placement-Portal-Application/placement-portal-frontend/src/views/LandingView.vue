<template>
<div>

<div>
<div @click="$router.push('/admin')">
    Admin 
</div>
</div>

<div>
<div @click="$router.push('/company')">   <!--router pushing to user-->
    Company 
</div>
</div>

</div>

<div>
<div @click="$router.push('/Student')">   <!--router pushing to user-->
    Student 
</div>
</div>




</template>

<script>
export default {
  name: 'LandingView'
}

</script>
