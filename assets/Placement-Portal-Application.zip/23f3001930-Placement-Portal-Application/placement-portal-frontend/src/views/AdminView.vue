<template>
  <div>
    <div v-if ="!isloggedIn">
      <AdminLogin @logged-in="handleAdminLogin" />
    </div>
    <div v-else>
      <AdminDashboard />
    </div>

  </div>

</template> 
<script>
import AdminDashboard from '@/components/AdminDashboard.vue';
import AdminLogin from '@/components/AdminLogin.vue';
import AdminAppliedStudents from '../components/AdminAppliedStudents.vue'
export default {
  name: "AdminView",
  components: {
    AdminLogin,
    AdminDashboard,
    AdminAppliedStudents
  },
  data() {
    return {
      isloggedIn: false
    }
  },
  methods: {
    handleAdminLogin() {
      this.isloggedIn = true;
    }
  }

}
</script>
