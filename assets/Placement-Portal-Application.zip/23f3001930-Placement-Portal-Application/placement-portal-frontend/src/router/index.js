import { createRouter, createWebHistory } from 'vue-router'
import LandingView from '../views/LandingView.vue'// so .. goes back to parent class(src) and then it cd to view/landing view.vue
import AdminView from '../views/AdminView.vue' 
import studentView from '../views/StudentView.vue'
import CompanyView from '../views/CompanyView.vue'
import StudentDrive from '../components/StudentDrive.vue'
import CompanyApplication from '../components/CompanyApplication.vue'
import CompanyInterview from '../components/CompanyInterview.vue'
import StudentApplicationHistory from '../components/StudentApplicationHistory.vue'
import StudentEditProfile from '../components/StudentEditProfile.vue'
const routes = [
  { path: '/', component: LandingView },
  { path: '/admin', component: AdminView }, //see above import AdminView keep it same here
  { path: '/student', component: studentView },
  { path: '/company', component: CompanyView },
  { path: '/company/drive/:id/applications', component: CompanyApplication },
  { path: '/company/application/:id/interview', component: CompanyInterview},
  { path: '/student/company/:id',component: StudentDrive },
  { path: '/student/applicationhistory', component: StudentApplicationHistory},
  { path: '/student/editprofile', component: StudentEditProfile },
  { path: '/:pathMatch(.*)*', redirect: '/' }  // it means whatevr path you are in come back to the same place 
]

const router = createRouter({
  history: createWebHistory(),
  routes
})

export default router