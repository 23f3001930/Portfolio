<template>
  <div>
    <h3>Open Drives</h3>
    <table class="table table-bordered">
      <thead>
        <tr>
          <th>ID</th>
          <th>Job Title</th>
          <th>Package</th>
          <th>Location</th>
          <th>Minimum CGPA</th>
          <th>Eligible Department</th>
          <th>Created At</th>
          <th>Deadline</th>
          <th>Status</th>
          <th>Action</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="drive in drives.filter(drive => drive.status === 'Open')" :key="drive.id">
          <td>{{drive.id}}</td>
          <td>{{drive.job_title}}</td>
          <td>{{drive.package}}</td>
          <td>{{drive.location}}</td>
          <td>{{drive.min_cgpa}}</td>
          <td>{{drive.eligible_department}}</td>
          <td>{{ drive.created_at }}</td>
          <td>{{ drive.deadline }}</td>
          <td>{{drive.status}}</td>
          <td>{{drive.approval}}</td>

          <td>
            <div class="d-flex gap-1 flex-nowrap">
              <button v-if="drive.approval !== 'Rejected'" @click="updateDrive(drive)">Update</button>
              <button v-if="drive.approval !== 'Rejected'" @click="completeDrive(drive.id)">Mark Complete</button>
              <button v-if="drive.approval !== 'Rejected'" @click="reviewApplications(drive.id)">Review
                Applications</button>
            </div>
          </td>
        </tr>
      </tbody>
    </table>

    <div v-if="selectedDrive">
      <h3>Update Drive</h3>

      <form @submit.prevent="saveDrive">

        <div>
          <label>Job Title:</label>
          <input type="text" v-model="selectedDrive.job_title" required>
        </div>
        <div>
          <label>Job Description:</label>
          <input type="text" v-model="selectedDrive.job_description" required>
        </div>
        <div>
          <label>Package:</label>
          <input type="number" step="0.1" v-model.number="selectedDrive.package" required>
        </div>
        <div>
          <label>Location:</label>
          <input type="text" v-model="selectedDrive.location" required>
        </div>
        <div>
          <label>Minimum CGPA:</label>
          <input type="number" step="0.1" v-model.number="selectedDrive.min_cgpa" required>
        </div>
        <div>
          <label>Eligible Department:</label>
          <select v-model="selectedDrive.eligible_department" required>
            <option disabled value="">Select Department</option>
            <option>Computer</option>
            <option>IT</option>
            <option>EXTC</option>
            <option>Mechanical</option>
            <option>Civil</option>
          </select>
        </div>

        <div>
          <label>Application Deadline:</label>
          <input type="datetime-local" v-model="selectedDrive.deadline" required>
        </div>
        <button type="submit">Update Drive</button>
      </form>
    </div>

    <br>

    <h3>Closed Drives</h3>
    <table class="table table-bordered">
      <thead>
      <tr>
        <th>ID</th>
        <th>Job Title</th>
        <th>Package</th>
        <th>Location</th>
        <th>Minimum CGPA</th>
        <th>Eligible Department</th>
        <th>Created At</th>
        <th>Deadline</th>
        <th>Status</th>
      </tr>
      </thead>
      <tbody>
      <tr v-for="drive in drives.filter(drive => drive.status === 'Complete')" :key="drive.id">
        <td>{{ drive.id }}</td>
        <td>{{ drive.job_title }}</td>
        <td>{{ drive.package }}</td>
        <td>{{ drive.location }}</td>
        <td>{{ drive.min_cgpa }}</td>
        <td>{{ drive.eligible_department }}</td>
        <td>{{ drive.created_at }}</td>
        <td>{{ drive.deadline }}</td>
        <td>{{ drive.status }}</td>
      </tr>
      </tbody>
    </table>
    <br>

  </div>
</template>

<script>
import axios from 'axios'
export default {
  name: 'CompanyDrives',

  data() {
    return {
      drives: [],
      selectedDrive: null,
    }
  },

  methods: {
    async fetchDrives() {
      const token = localStorage.getItem('token')

      const res = await axios.get(
        'http://localhost:5000/api/company/drives',
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      )

      console.log('Company Drives response:', res.data)
      this.drives = res.data || []
    },
    updateDrive(drive) {
      this.selectedDrive = { ...drive }
    },
    reviewApplications(id) {
      this.$router.push(`/company/drive/${id}/applications`)
    },
    async saveDrive() {
      const token = localStorage.getItem('token')

      await axios.put(
        `http://localhost:5000/api/update/drive/${this.selectedDrive.id}`,
        this.selectedDrive,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      )

      this.selectedDrive = null
      this.fetchDrives()
    },
    async completeDrive(id) {
      const token = localStorage.getItem('token')

      await axios.put(
        `http://localhost:5000/api/drive/${id}/complete`,
        {},
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }  )

      this.fetchDrives()
    },
  },

  mounted() {
    this.fetchDrives()
  },
}
</script>