<template>
  <div>
    <h1>Student Login</h1>
    <form @submit.prevent="handleLogin">
      <div>
        <label for="email">email:</label>
        <input type="text" id="email" name="email" v-model="form.email" required>
      </div>
      <div>
        <label for="password">Password:</label>
        <input type="password" id="password" name="password" v-model="form.password" required>
      </div>
      <button type="submit">Login</button>
      <button @click="goHome">Back to Home </button>
    </form>
    <a href="#" @click.prevent="$emit('register-here')">register here</a>

  </div>
</template>

<script>
import axios from 'axios';
export default {
  name: 'StudentLogin',
  data () {
    return {
      form: {
        email: '',
        password: ''
      }
    }
  },
  methods: {
    async handleLogin () {
      try {
        const response = await axios.post('http://localhost:5000/api/login', this.form)
        console.log('Login response:', response.data)
        localStorage.setItem('token', response.data.data.access_token)
        this.$emit('logged-in')
      } catch (error) {
        console.error('Login error:', error)
        alert(error.response.data.message)
      }
    },
    goHome() {
      this.$router.push('/')
    }
  }
}
</script>