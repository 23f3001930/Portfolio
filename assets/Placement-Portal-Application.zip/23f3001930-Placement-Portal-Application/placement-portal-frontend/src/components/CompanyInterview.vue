<template>
    <div>
        <h1>Interview Details</h1>
        <form @submit.prevent="scheduleInterview">
            <div>
                <label>Interview Date & Time:</label>
                <input type="datetime-local" v-model="form.interview_datetime" required />
            </div>
            <div>
                <label>Meeting Link:</label>
                <input type="text" v-model="form.meeting_link" required />
            </div>
            <div>
                <label>Feedback:</label>
                <textarea v-model="form.feedback"> </textarea>
            </div>
            <button type="submit"> Schedule Interview </button>
        </form>
        <button @click="goBack"> Go Back</button>
    </div>
</template>
<script>
import axios from 'axios'
export default {
    name: 'CompanyShortlisted',
    data() {
        return {
            form: {
                interview_datetime: '',
                meeting_link: '',
                feedback: ''
            }
        }
    },
    methods: {
        async scheduleInterview() {
            try {
                const token = localStorage.getItem('token')
                const id = this.$route.params.id
                await axios.put(
                    `http://localhost:5000/api/company/application/${id}/interview`,
                    this.form,
                    {
                        headers: {
                            Authorization: `Bearer ${token}`,
                        },
                    }
                )
                alert('Interview Saved Successfully')
                this.$router.push('/company')
            } catch (error) {
                console.error(error)
                alert('Failed to schedule interview.')
            }
        },
        async fetchInterview() {
            const token = localStorage.getItem('token')
            const id = this.$route.params.id
            const res = await axios.get(
                `http://localhost:5000/api/company/application/${id}`,
                {
                    headers: {
                        Authorization: `Bearer ${token}`,
                    },
                }
            )
            this.form.interview_datetime = res.data.interview_datetime
            this.form.meeting_link = res.data.meeting_link
            this.form.feedback = res.data.feedback
            this.student = {
                student_name: res.data.student_name,
                student_email: res.data.student_email,
                department: res.data.department,
                cgpa: res.data.cgpa
            }
        },
        goBack() {
            this.$router.push('/company')
        }
    },
    mounted() {
        this.fetchInterview()
    }
}
</script>