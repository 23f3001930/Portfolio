<template>
    <div>
        <h2>Placement History</h2>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Company</th>
                    <th>Job Title</th>
                    <th>Package</th>
                    <th>Location</th>
                    <th>Status</th>
                    <th>Interview Date & Time</th>
                    <th>Meeting Link</th>
                    <th>Feedback</th>
                    <th>Offer Letter</th>
                </tr>
            </thead>
            <tbody>
                <tr v-for="application in applications" :key="application.id">
                    <td>{{ application.company_name }}</td>
                    <td>{{ application.job_title }}</td>
                    <td>{{ application.package }}</td>
                    <td>{{ application.location }}</td>
                    <td>{{ application.status }}</td>
                    <td>{{ application.interview_datetime }}</td>
                    <td>{{ application.meeting_link }}</td>
                    <td>{{ application.feedback }}</td>
                    <td>
                        <button @click="viewOfferLetter(application)">
                            View Offer Letter
                        </button>
                    </td>
                </tr>
            </tbody>
        </table>
        <br>
        <button @click="goBack"> Go Back </button>
    </div>
</template>
<script>
import axios from 'axios'

export default {

    name: 'StudentApplicationHistory',
    data() {
        return {
            applications: []
        }
    },
    methods: {
        async fetchHistory() {
            const token = localStorage.getItem('token')
            const res = await axios.get(
                'http://localhost:5000/api/student/applicationhistory',
                {
                    headers: {
                        Authorization: `Bearer ${token}`,
                    },
                }
            )
            this.applications = res.data
        },
        viewOfferLetter(application) {
            if (application.status != 'Selected' || !application.offer_letter) {
                alert('Offer Letter is available only for selected students.')
                return
            }
            window.open(
                `http://localhost:5000/static/offerletters/${application.offer_letter}`, '_blank' )
        },
        goBack() {
            this.$router.push('/student')
        }
    },
    mounted() {
        this.fetchHistory()
    },
}
</script>