<template>
  <div>

    <header>
      <h2>Student Dashboard</h2>
      <button @click="logout">Logout</button>
    </header>
    <button @click="viewHistory">
        Placement History
    </button>
    <button @click="exportApplications">
      Export Applications
    </button>
    <button @click="editProfile">
      Edit Profile
    </button>
    <h3>Companies</h3>
    <div>
      <label>Search Companies:</label>
      <input type="text" v-model="search" placeholder="Search Company, Job Title or Location" >
    </div>
    <table class="table table-bordered">
      <thead>
        <tr>
          <th>ID</th>
          <th>Company Name</th>
          <th>Action</th>
        </tr>
        </thead>
        <tbody>
        <tr v-for="company in filteredCompanies" :key="company.id">
          <td>{{ company.id }}</td>
          <td>{{ company.username }}</td>

          <td>
            <button @click="viewCompany(company.id)">
              View Drive
            </button>
          </td>
        </tr>
        </tbody>
    </table>

    <br>

    <h3>Applied Drives</h3>

    <table class="table table-bordered">
      <thead>
        <tr>
          <th>ID</th>
          <th>Drive Name</th>
          <th>Company</th>
          <th>Date</th>
          <th>Interview Date & Time</th>
          <th>Meeting Link</th>
          <th>Feedback</th>
          <th>Status</th>
        </tr>
        <tr v-for="application in applications" :key="application.id">
          <td>{{ application.id }}</td>
          <td>{{ application.job_title }}</td>
          <td>{{ application.company_name }}</td>
          <td>{{ application.applied_date }}</td>
          <td>{{ application.interview_datetime }}</td>
          <td>{{ application.meeting_link  }}</td>
          <td>{{ application.feedback }}</td>
          <td>{{ application.status }}</td>
        </tr> 
        </thead>
    </table>

  </div>
</template>

<script>
import axios from 'axios'

export default {
  name: 'StudentDashboard',

  data() {
    return {
      companies: [],
      applications: [],
      search: ''
    }
  },

  methods: {
    async fetchCompanies() {
      const token = localStorage.getItem('token')

      const res = await axios.get(
        'http://localhost:5000/api/student/companies',
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      )

      this.companies = res.data
    },

    async fetchApplications() {
      const token = localStorage.getItem('token')

      const res = await axios.get(
        'http://localhost:5000/api/student/applications',
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      )

      this.applications = res.data
    },

    viewCompany(id) {
      this.$router.push(`/student/company/${id}`)
    },

    viewApplication(id) {
      this.$router.push(`/student/application/${id}`)
    },

    logout() {
      localStorage.removeItem('token')
      this.$router.push('/')
    },
    viewHistory() {
      this.$router.push('/student/applicationhistory')
    },
    async exportApplications() {
      const token = localStorage.getItem("token");
      await axios.get("http://localhost:5000/api/export/applications",
      {
        headers: {
          Authorization: `Bearer ${token}`
            }
      }     );
      alert("Applications report is being generated and will be sent to your email.");
      },
    editProfile() {
      this.$router.push('/student/editprofile')
    }
  },


  computed: {
    filteredCompanies() {
      const search = this.search.toLowerCase()
      return this.companies.filter(company => company.username.toLowerCase().includes(search) ||
        company.job_title.toLowerCase().includes(search) ||
        company.location.toLowerCase().includes(search)   )
    },
  },
  mounted() {
    this.fetchCompanies()
    this.fetchApplications()
  },
}
</script>