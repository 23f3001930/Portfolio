<template>
  <div>
    <h4>Total Students: {{ totalStudents }}</h4>
    <div>
      <label>Search Students:</label>
      <input type="text" v-model="searchStudent" placeholder="Search by username, email ">
    </div>
    <h4>Students</h4>
    <table class="table table-bordered">
      <thead>
      <tr>
        <th>ID</th>
        <th>Username</th>
        <th>Email</th>
        <th>Role</th>
        <th>Blacklist</th>
      </tr>
      </thead>
      <tbody>
      <tr v-for="user in filteredStudents" :key="user.id">
        <td>{{ user.id }}</td>
        <td>{{ user.username }}</td>
        <td>{{ user.email }}</td>
        <td>{{ user.role }}</td>

        <td>
          <button v-if="!user.blacklist" @click="blacklistStudent(user.id)">
            Blacklist
          </button>
          <button v-else @click="unblacklistStudent(user.id)">
            Unblacklist
          </button>
        </td>
      </tr>
        </tbody>

    </table>

    <br>
    <h4>Total Companies: {{ totalCompanies }}</h4>
    <div>
      <label>Search Companies:</label>
      <input type="text" v-model="searchCompany" placeholder="Search by username or email">
    </div>
    <h4>Companies</h4>
    <table class="table table-bordered">
      <thead>
      <tr>
        <th>ID</th>
        <th>Username</th>
        <th>Email</th>
        <th>Role</th>
        <th>Status</th>
        <th>Action</th>
        <th>Blacklist</th>
      </tr>
      </thead>
      <tbody>
      <tr v-for="user in filteredCompanies" :key="user.id">
        <td>{{ user.id }}</td>
        <td>{{ user.username }}</td>
        <td>{{ user.email }}</td>
        <td>{{ user.role }}</td>
        <td>{{ user.status }}</td>

        <td>
          <div v-if="user.status === 'Pending'" class="dropdown">
            <button
              class="btn btn-secondary dropdown-toggle"
              type="button"
              id="dropdownMenuButton1"
              data-bs-toggle="dropdown"
              aria-expanded="false">

              Action
            </button>
            <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
              <li>
                <a class="dropdown-item" href="#" @click.prevent="approveCompany(user.id)">
                  Approve
                </a>
              </li>
              <li>
                <a class="dropdown-item" href="#" @click.prevent="rejectCompany(user.id)">
                  Reject
                </a>
              </li>
            </ul>
          </div>
          <span v-else>
            {{ user.status }}
          </span>
        </td>
        <td>
          <button v-if="!user.blacklist" @click="blacklistCompany(user.id)">
            Blacklist
          </button>
          <button v-else @click="unblacklistCompany(user.id)">
            Unblacklist
          </button>
        </td>
      </tr>
      </tbody>
    </table>
    <h4>Total Placement Drives: {{ totalDrives }}</h4>
    <div>
      <label>Search Drives:</label>
      <input type="text" v-model="searchDrive" placeholder="Search by company, job title or location">
    </div>
    <h4>Drives</h4>
    <table class="table table-bordered">
      <thead>
      <tr>
        <th>ID</th>
        <th>Company Name</th>
        <th>Job Title</th>
        <th>Package</th>
        <th>Location</th>
        <th>Status</th>
        <th>Created At</th>
        <th>Application Deadline</th>
        <th>Action</th>
        <th>Blacklist</th>
      </tr>
      </thead>
      <tbody>
      <tr v-for="drive in filteredDrives" :key="drive.id">
        <td>{{ drive.id }}</td>
        <td>{{ drive.company_name }}</td>
        <td>{{ drive.job_title }}</td>
        <td>{{ drive.package }}</td>
        <td>{{ drive.location }}</td>
        <td>{{ drive.status }}</td>
        <td>{{ drive.created_at }}</td>
        <td>{{ drive.deadline }}</td>
        <td>
          <div v-if="drive.approval === 'Pending'" class="dropdown">
            <button
              class="btn btn-secondary dropdown-toggle"
              type="button"
              id="dropdownMenuButton1"
              data-bs-toggle="dropdown"
              aria-expanded="false">
              Action
            </button>

            <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">

              <li>
                <a class="dropdown-item" href="#" @click.prevent="approveDrive(drive.id)">
                  Approve
                </a>
              </li>

              <li>
                <a class="dropdown-item" href="#" @click.prevent="rejectDrive(drive.id)">
                  Reject
                </a>
              </li>

            </ul>

          </div>

          <span v-else>
            {{ drive.approval }}
          </span>

        </td>

        <td>
          <button v-if="!drive.blacklist" @click="blacklistDrive(drive.id)">
            Blacklist
          </button>
          <button v-else @click="unblacklistDrive(drive.id)">
            Unblacklist
          </button>
        </td>
      </tr>
      </tbody>
    </table>
  </div>
</template>
<script>
import axios from 'axios'

export default {
  name: 'AdminUsers',
  data() {
    return {
      users: [],
      drives: [],
      searchStudent: '',
      searchCompany: '',
      searchDrive: ''
    }
  },
  methods: {
    async fetchUserDetails() {
      const token = localStorage.getItem('admin_token')
      const res = await axios.get('http://localhost:5000/api/get-data', {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      })
      console.log('User Details response:', res.data)
      this.users = res.data || []
    },
    async blacklistStudent(id) {
      const token = localStorage.getItem('admin_token')

      await axios.delete(
        `http://localhost:5000/api/blacklist/student/${id}`,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      )

      this.fetchUserDetails()
    },
    async unblacklistStudent(id) {
      const token = localStorage.getItem('admin_token')
      await axios.put(
        `http://localhost:5000/api/unblacklist/student/${id}`,
        {},
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      )
      this.fetchUserDetails()
    },
    async approveCompany(id) {
      const token = localStorage.getItem('admin_token')

      await axios.put(
        `http://localhost:5000/api/company/${id}/approve`,
        {},
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      )

      this.fetchUserDetails()
    },

    async rejectCompany(id) {
      const token = localStorage.getItem('admin_token')

      await axios.put(
        `http://localhost:5000/api/company/${id}/reject`,
        {},
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      )

      this.fetchUserDetails()
    },

    async blacklistCompany(id) {
      const token = localStorage.getItem('admin_token')

      await axios.delete(
        `http://localhost:5000/api/blacklist/company/${id}`,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      )
      this.fetchUserDetails()
    },
    async unblacklistCompany(id) {
      const token = localStorage.getItem('admin_token')
      await axios.put(
        `http://localhost:5000/api/unblacklist/company/${id}`,
        {},
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      )
      this.fetchUserDetails()
    },

    async fetchDriveDetails() {
      const token = localStorage.getItem('admin_token')

      const res = await axios.get(
        'http://localhost:5000/api/admin/drives',
        {
          headers: {
            Authorization: `Bearer ${token}`
          }
        }
      )

      console.log('Drive Details response:', res.data)
      this.drives = res.data || []
    },
    async approveDrive(id) {
      const token = localStorage.getItem('admin_token')

      await axios.put(
        `http://localhost:5000/api/drive/${id}/approve`,
        {},
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      )

      this.fetchDriveDetails()
    },
    async rejectDrive(id) {
      const token = localStorage.getItem('admin_token')

      await axios.put(
        `http://localhost:5000/api/drive/${id}/reject`,
        {},
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      )

      this.fetchDriveDetails()
    },
    async blacklistDrive(id) {
      const token = localStorage.getItem('admin_token')

      await axios.delete(
        `http://localhost:5000/api/blacklist/drive/${id}`,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      )

      this.fetchDriveDetails()
    },
    async unblacklistDrive(id) {
      const token = localStorage.getItem('admin_token')

      await axios.put(
        `http://localhost:5000/api/unblacklist/drive/${id}`,
        {},
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      )

      this.fetchDriveDetails()
    }

  },

  computed: {
    totalStudents() {
      return this.users.filter(user => user.role === 'student').length
    },

    totalCompanies() {
      return this.users.filter(user => user.role === 'company').length
    },

    totalDrives() {
      return this.drives.length
    },
    filteredStudents() {
      const search = this.searchStudent.toLowerCase()
      return this.users.filter(user => user.role === 'student' &&
        ( user.username.toLowerCase().includes(this.searchStudent.toLowerCase()) ||
          user.email.toLowerCase().includes(this.searchStudent.toLowerCase())  )
      )
    },

    filteredCompanies() {
      const search = this.searchCompany.toLowerCase()
      return this.users.filter(user => user.role === 'company' &&
        (user.username.toLowerCase().includes(this.searchCompany.toLowerCase()) ||
          user.email.toLowerCase().includes(this.searchCompany.toLowerCase()) )
      )
    },

    filteredDrives() {
      const search = this.searchDrive.toLowerCase()

      return this.drives.filter(drive =>
        drive.company_name.toLowerCase().includes(search) ||
        drive.job_title.toLowerCase().includes(search) ||
        drive.location.toLowerCase().includes(search)
      )
    },
  },
  mounted() {
    this.fetchUserDetails()
    this.fetchDriveDetails()

  },
}
</script>