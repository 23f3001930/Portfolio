<template>
    <div>
        <h1>Create Drive</h1>
        <form @submit.prevent="createDrive">
            <div>
                <label for="job_title">Job Title:</label>
                <input type="text" id="job_title" v-model="form.job_title" required/>
            </div>
            <div>
                <label for="job_description">Job Description:</label>
                <input type="text" id="job_description" v-model="form.job_description" required/>
            </div>
            <div>
                <label for="package">Package:</label>
                <input type="number" step="0.01" id="package" v-model.number="form.package" required/>
            </div>
            <div>
                <label for="location">Location:</label>
                <input type="text" id="location" v-model="form.location" required/>
            </div>
            <div>
                <label for="min_cgpa">Minimum CGPA:</label>
                <input type="number" step="0.1" v-model.number="form.min_cgpa" required />
            </div>

            <div>
            <label>Minimum Year:</label>
                <select v-model="form.min_year" required>
                    <option disabled value="">Select Year</option>
                    <option :value="1">1</option>
                    <option :value="2">2</option>
                    <option :value="3">3</option>
                    <option :value="4">4</option>
                </select>
            </div>

            <div>
                <label for="eligible_department">Eligible Department:</label>
                <select v-model="form.eligible_department" required>
                    <option disabled value="">Select Department</option>
                    <option>Computer</option>
                    <option>IT</option>
                    <option>EXTC</option>
                    <option>Mechanical</option>
                    <option>Civil</option>
                </select>
            </div>

            <div>
                <label>Application Deadline:</label>
                <input type="datetime-local" v-model="form.deadline" required>
            </div>
            <button type="submit">Create Drive</button>

    </form>
    </div>
</template>

<script>
import axios from 'axios'

export default {
    name: 'CompanyCreateDrive',
    data() {
        return {
        form: {
            job_title: '',
            job_description: '',
            package: 0,
            location: '',
            min_cgpa: 0,
            min_year: 0,
            eligible_department: '',
            
            deadline: ''
        },
        }
    },

    methods: {
        async createDrive() {
            try {
                const token = localStorage.getItem('token')
                await axios.post('http://localhost:5000/api/create/drive', this.form, {
                    headers: {
                       Authorization: `Bearer ${token}`,
                    },
                })
                alert("Drive created successfully! Waiting for admin approval.")
                this.form = {
                    job_title: '',
                    job_description: '',
                    package: 0,
                    location: '',
                    min_cgpa: 0,
                    min_year: 0,
                    eligible_department: '',
                    deadline: ''
                }
                this.$emit('drive-created')
            } catch (error) {
                console.error('Error creating drive:', error)
                alert('Failed to create drive.')
            }
        },
    },
}
</script>