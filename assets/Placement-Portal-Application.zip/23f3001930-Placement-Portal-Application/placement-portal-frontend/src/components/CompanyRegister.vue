<template>
<div>
    <h1>Company Registration</h1>
    <form @submit.prevent="handleRegister">
        <div>
            <label for="username">Username:</label>
            <input type="text" id="username" name="username" v-model="form.username" required>
        </div>

        <div>
            <label for="email">Email:</label>
            <input type="email" id="email" v-model="form.email" required>
        </div>

        <div>
            <label for="password">Password:</label>
            <input type="password" id="password" v-model="form.password" required>
        </div>

        <div>
            <label for="hr_contact">HR Contact:</label>
            <input type="text" id="hr_contact" v-model="form.hr_contact" required>
        </div>

        <div>
            <label for="website">Website:</label>
            <input type="text" id="website" v-model="form.website">
        </div>

        <button type="submit">Register</button>

    </form>

    <a href="#" @click.prevent="$emit('login-here')">
        Already have an account? Login
    </a>

</div>
</template>

<script>
import axios from 'axios'

export default {
    name: 'CompanyRegister',
    emits: ['registered','login-here'],

    data() {
        return {
            form: {
                username: '',
                email: '',
                password: '',
                hr_contact: '',
                website: ''
            }
        }
    },

    methods: {
        async handleRegister() {
            try {
                const response = await axios.post('http://localhost:5000/api/company/register', this.form); 
                alert(response.data.message);
                this.$emit('registered')  

            } 
            catch (error) {                                                    
                console.error('Registration failed:', error); 
                alert(error.response.data.message);
            }
        }   
    }
}
</script>

