<template>
  <div>
    <header>
      <h2>Company Dashboard</h2>
      <p>HR Contact: {{ hr_contact }}</p>
      <p>Website: {{ website }}</p>
      <button @click="logout">Logout</button>
    </header>

    <nav>
      <button
        @click="activeTab='drives'"
        :class="{ active: activeTab==='drives' }">
        Drives
      </button>

      <button
        @click="activeTab='createDrive'"
        :class="{ active: activeTab==='createDrive' }">
        Create Drive
      </button>
      <button @click="exportCompanyApplications">
        Export Applications
      </button>
    </nav>

    <main>
      <CompanyDrives v-if="activeTab==='drives'" />
      <CompanyCreateDrive v-if="activeTab==='createDrive'" />

    </main>

  </div>
</template>

<script>
import axios from 'axios'
import CompanyDrives from '../components/CompanyDrives.vue'
import CompanyCreateDrive from '../components/CompanyCreateDrive.vue'
import CompanyApplication from '../components/CompanyApplication.vue'
import CompanyInterview from '../components/CompanyInterview.vue'
export default{
  name:'CompanyDashboard',

  components:{
    CompanyDrives,
    CompanyCreateDrive,
    CompanyApplication,
    CompanyInterview
  },   

  data(){
    return{
      hr_contact: '',
      website: '',
      activeTab:'drives',

    }
  },
methods: {
    async fetchCompanyProfile() {
      const token = localStorage.getItem('token')

      const res = await axios.get(
        'http://localhost:5000/api/company/profile',
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      )

      this.hr_contact = res.data.hr_contact
      this.website = res.data.website
    },
    async exportCompanyApplications() {
      const token = localStorage.getItem("token");
      await axios.get("http://localhost:5000/api/export/company/applications",
        {
          headers: {
            Authorization: `Bearer ${token}`
          }
        }
      );
      alert("Applications report is being generated and will be sent to your email.");
    },
    logout(){
      localStorage.removeItem('token')
      this.$router.push('/')
  } },
  mounted() {
  this.fetchCompanyProfile()
}
}
</script>