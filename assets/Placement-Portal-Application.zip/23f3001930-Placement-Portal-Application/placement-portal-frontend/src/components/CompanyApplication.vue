<template>
  <div>
    <h3>Received Applications</h3>
    <table class="table table-bordered">
      <thead>
        <tr>
          <th>Student Name</th>
          <th>Student Email</th>
          <th>Department</th>
          <th>CGPA</th>
          <th>Year</th>
          <th>Resume</th>
          <th>Status</th>
          <th>Select</th>
          <th>Interview Date & Time</th>
          <th>Meeting Link</th>
          <th>Feedback</th>
          <th>offer letter</th>
        </tr>
      </thead>

      <tbody>
        <tr v-for="application in application_details" :key="application.id">
          <td>{{ application.student_name }}</td>
          <td>{{ application.student_email }}</td>
          <td>{{ application.department }}</td>
          <td>{{ application.cgpa }}</td>
          <td>{{ application.year }}</td>

          <td>
            <button @click="viewResume(application.resume)">
              View Resume
            </button>
          </td>
          <td>{{ application.status }}</td>
          <td>
            <div class="dropdown">
              <button class="btn btn-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown"
                aria-expanded="false">
                Select
              </button>
              <ul class="dropdown-menu">
                <li>
                  <button class="dropdown-item" type="button" @click="scheduleInterview(application.id)">
                    Shortlisted
                  </button>
                </li>

                <li>
                  <button class="dropdown-item" type="button" @click="updateStatus(application.id, 'Selected')">
                    Selected
                  </button>
                </li>
                <li>
                  <button class="dropdown-item" type="button" @click="updateStatus(application.id, 'Offer')">
                    Offer
                  </button>
                </li>

                <li>
                  <button class="dropdown-item" type="button" @click="updateStatus(application.id, 'Rejected')">
                    Rejected
                  </button>
                </li>
              </ul>
            </div>

          </td>
            <td>{{ application.interview_datetime }}</td>
            <td>{{ application.meeting_link }}</td>
            <td>{{ application.feedback }}</td>

          <td>
            <button v-if="application.offer_letter" @click="viewOfferLetter(application.offer_letter)">
              View Offer Letter
            </button>
          </td>

          <td>
            <input type="file" accept=".pdf" @change="selectOfferLetter">
            <button @click="uploadOfferLetter(application)"> Upload </button>
          </td>
        </tr>
      </tbody>
    </table>
    <button @click="goBack"> Go Back </button>
  </div>

</template>

<script>
import axios from 'axios'

export default {
  name: 'CompanyApplications',
  data() {
    return {
      application_details: [],
      offer_letter: null,
    }
  },
  methods: {
    async fetchApplicationDetails() {
      const token = localStorage.getItem('token')
      const drive_id = this.$route.params.id

      const response = await axios.get(
        `http://localhost:5000/api/drive/${drive_id}/applications`,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      )
      this.application_details = response.data
    },

    viewResume(resume) {
      window.open(
        `http://localhost:5000/static/resumes/${resume}`, '_blank')
    },

    async updateStatus(id, status) {
      const token = localStorage.getItem('token')

      await axios.put(
        `http://localhost:5000/api/company/application/${id}/status`,
        {
          status: status,
        },
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      )
      alert('Application status updated successfully')
      this.fetchApplicationDetails()
    },
    scheduleInterview(id) {
      this.$router.push(`/company/application/${id}/interview`)
    },
    viewOfferLetter(offer_letter) {
      window.open(`http://localhost:5000/static/offerletters/${offer_letter}`, '_blank')
    },

    selectOfferLetter(event) {
      this.offer_letter = event.target.files[0]
    },
    async uploadOfferLetter(application) {
      if (application.status != 'Offer') {
        alert('Offer Letter can only be uploaded for selected students.')
        return
      }
      const token = localStorage.getItem('token')
      const formData = new FormData()
      formData.append('offer_letter', this.offer_letter)
      await axios.post(
        `http://localhost:5000/api/company/application/${application.id}/offerletter`,
        formData,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      )
      alert('Offer Letter uploaded successfully')
    },
    goBack() { this.$router.push('/company') }
  },
  mounted() {
    this.fetchApplicationDetails()
  },
}
</script>