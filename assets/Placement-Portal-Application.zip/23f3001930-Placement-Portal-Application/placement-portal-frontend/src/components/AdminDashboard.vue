<template>
  <div>
    <header>
      <h3>Admin Dashboard</h3>
      <button @click="logout()">Logout</button>
    </header>
    <nav>              

      <button @click="activeTab = 'users'" :class="{ active: activeTab === 'users' }">Users</button>
      <button @click="activeTab = 'appliedStudents'" :class="{ active: activeTab === 'appliedStudents' }"> Applied Student </button>
    </nav>
    <main>

      <AdminUsers v-if="activeTab === 'users'" />
      <AdminAppliedStudents v-if="activeTab === 'appliedStudents'" />
    </main>
    
  </div>
</template>
<script>

import AdminUsers from '../components/AdminUsers.vue';
import AdminAppliedStudents from '../components/AdminAppliedStudents.vue'
export default {
  name: 'AdminDashboard',
  components: { AdminUsers, AdminAppliedStudents },

  data() {
    return {
      activeTab: 'users',
    }
  },
  methods: {

    logout() {
      localStorage.removeItem('admin_token');
      this.$router.push('/');
    }
  }
}
</script>