<template>
  <div>
    <h1>Admin Login</h1>
    <form @submit.prevent="handleLogin">
      <div>
        <label for="email">email:</label>
        <input type="text" id="email" name="email" v-model="form.email" required />
      </div>
      <div>
        <label for="password">Password:</label>
        <input type="password" id="password" name="password" v-model="form.password" required />
      </div>
      <button type="submit">Login</button>
      <button @click="goHome"> Back to Home</button>
    </form>
  </div>
</template>

<script>
import axios from 'axios'
export default {
  name: 'AdminLogin',
  data() {
    return {
      form: {
        email: '',
        password: '',
      },
    }
  },
  methods: {
    async handleLogin() {
      try {
        const response = await axios.post('http://localhost:5000/api/admin/login', this.form)  
        console.log('Admin Login response:', response.data) 
        localStorage.setItem('admin_token', response.data.data.access_token)   
        this.$emit('logged-in')                         
      } catch (error) {                                  
        console.error('Admin Login error:', error)
        alert(error.response.data.message)
      }
    },
    goHome() {
      this.$router.push('/')
    }
  },
}
</script>