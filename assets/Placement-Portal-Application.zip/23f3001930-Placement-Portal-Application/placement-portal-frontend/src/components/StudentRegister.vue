<template>
<div>
    <h1>Student Registration</h1>
    <form @submit.prevent="handleRegister" >
        <div>
            <label for="username">Username:</label>
            <input type="text" id="username" name="username" v-model="form.username" required>
        </div>
        <div>
            <label for="email">Email:</label>
            <input type="email" id="email" name="email" v-model="form.email" required>
        </div>
        <div>
            <label for="password">Password:</label>
            <input type="password" id="password" name="password" v-model="form.password" required>
        </div>
        <div>
            <label for="department">Department:</label>
            <select id="department" v-model="form.department" required>
                <option disabled value="">Select Department</option>
                <option>Computer</option>
                <option>IT</option>
                <option>EXTC</option>
                <option>Mechanical</option>
                <option>Civil</option>
            </select>
        </div>

        <div>
            <label for="cgpa">CGPA:</label>
            <input type="number" step="0.01" id="cgpa" name="cgpa" v-model.number="form.cgpa" required>
        </div>

        <div>
            <label>Year:</label>
                <select v-model="form.year" required>
                    <option disabled value="">Select Year</option>
                    <option :value="1">1</option>
                    <option :value="2">2</option>
                    <option :value="3">3</option>
                    <option :value="4">4</option>
                </select>
        </div>
        <button type="submit">Register</button>

    </form>
    <a href="#" @click.prevent="$emit('login-here')">
        Already have an account? Login
    </a> 
</div>

</template>

<script>                     
import axios from 'axios'

export default {
    name: 'StudentRegister',
    emits:['registered','login-here'],
    data() {
        return {
            form : {
                username: '',
                email: '',
                password: '',
                department: '',
                cgpa: 0,
                year: 0
            }
        }
    },
    methods: {          
        async handleRegister() {
            try {
                const response = await axios.post('http://localhost:5000/api/register', this.form); 
                alert(response.data.message);
                this.$emit('registered')                                               
            } 
            catch (error) {                                                    
                console.error('Registration failed:', error); 
                alert(error.response.data.message);          
            }
        }         
    }
}
</script>