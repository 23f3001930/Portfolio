<template>
<div>
    <h1>Edit Profile</h1>

    <form @submit.prevent="updateProfile">

        <div>
            <label for="username">Username:</label>
            <input type="text" id="username" v-model="form.username" required>
        </div>

        <div>
            <label for="email">Email:</label>
            <input type="email" id="email" v-model="form.email" required>
        </div>

        <div>
            <label for="department">Department:</label>
            <select id="department" v-model="form.department" required>
                <option>Computer</option>
                <option>IT</option>
                <option>EXTC</option>
                <option>Mechanical</option>
                <option>Civil</option>
            </select>
        </div>

        <div>
            <label for="cgpa">CGPA:</label>
            <input
                type="number"
                step="0.01"
                id="cgpa"
                v-model.number="form.cgpa"
                required>
        </div>

        <div>
            <label>Year:</label>
            <select v-model="form.year" required>
                <option :value="1">1</option>
                <option :value="2">2</option>
                <option :value="3">3</option>
                <option :value="4">4</option>
            </select>
        </div>

        <button type="submit">
            Update Profile
        </button>

    </form>

</div>
</template>

<script>
import axios from 'axios'

export default {

    name: 'StudentEditProfile',

    data() {
        return {
            form: {
                username: '',
                email: '',
                department: '',
                cgpa: 0,
                year: 0
            }
        }
    },

    methods: {

        async fetchProfile() {

            const token = localStorage.getItem('token')

            const response = await axios.get(
                'http://localhost:5000/api/student/profile',
                {
                    headers: {
                        Authorization: `Bearer ${token}`
                    }
                }
            )

            this.form = response.data
        },

        async updateProfile() {

            try {

                const token = localStorage.getItem('token')

                const response = await axios.put(
                    'http://localhost:5000/api/student/editprofile',
                    this.form,
                    {
                        headers: {
                            Authorization: `Bearer ${token}`
                        }
                    }
                )

                alert(response.data.message)

                this.$router.push('/student')

            }

            catch(error) {

                console.error('Update failed:', error)

                alert(error.response.data.message)

            }

        }

    },

    mounted() {

        this.fetchProfile()

    }

}
</script>