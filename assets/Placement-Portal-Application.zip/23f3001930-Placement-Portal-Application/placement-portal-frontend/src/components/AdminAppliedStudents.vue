<template>
  <div>
    <h3>Applied Students</h3>
    <table class="table table-bordered">
      <thead>
        <tr>
          <th>ID</th>
          <th>Student Name</th>
          <th>Company Name</th>
          <th>Job Title</th>
          <th>Package</th>
          <th>Location</th>
          <th>Application Deadline</th>
          <th>Status</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="application in applications" :key="application.id">
          <td>{{ application.id }}</td>
          <td>{{ application.student_name }}</td>
          <td>{{ application.company_name }}</td>
          <td>{{ application.job_title }}</td>
          <td>{{ application.package }}</td>
          <td>{{ application.location }}</td>
          <td>{{ application.deadline }}</td>
          <td>{{ application.status }}</td>
        </tr>
      </tbody>
    </table>
  </div>
</template>

<script>
import axios from 'axios'
export default {
  name: 'AdminAppliedStudents',
  data() {
    return {
      applications: []
    }
  },
  methods: {
    async fetchApplications() {
      const token = localStorage.getItem('admin_token')
      const res = await axios.get(
        'http://localhost:5000/api/admin/appliedstudents',
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }  )
      console.log(res.data)
      this.applications = res.data || []
    },
  },
  mounted() {
    this.fetchApplications()
  }
}
</script>