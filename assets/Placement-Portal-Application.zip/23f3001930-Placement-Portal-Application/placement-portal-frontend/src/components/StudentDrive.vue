<template>
  <div>

    <div v-if="!selectedDrive">
      <h3>Current Drives</h3>

      <table class="table table-bordered">
        <thead>
          <tr>
            <th>ID</th>
            <th>Job Title</th>
            <th>Package</th>
            <th>Location</th>
            <th>Minimum CGPA</th>
            <th>Eligible Department</th>
            <th>Created At</th>
            <th>Application Deadline</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="drive in drives" :key="drive.id">
            <td>{{ drive.id }}</td>
            <td>{{ drive.job_title }}</td>
            <td>{{ drive.package }}</td>
            <td>{{ drive.location }}</td>
            <td>{{drive.min_cgpa}}</td>
            <td>{{drive.eligible_department}}</td>
            <td>{{ drive.created_at }}</td>
            <td>{{ drive.deadline }}</td>
            <td>
              <button @click="viewDrive(drive)">
                Details
              </button>
            </td>
          </tr>
        </tbody>
      </table>
      <br>

      <button @click="goToDashboard">
        Go Back
      </button>
    </div>

    <div v-if="selectedDrive">
      <h2>Drive Details</h2>
      <p><strong>Job Title:</strong> {{ selectedDrive.job_title }}</p>
      <p><strong>Job Description:</strong> {{ selectedDrive.job_description }}</p>
      <p><strong>Package:</strong> {{ selectedDrive.package }}</p>
      <p><strong>Location:</strong> {{ selectedDrive.location }}</p>
      <p><strong>Minimum CGPA:</strong> {{ selectedDrive.min_cgpa }}</p>
      <p><strong>Eligible Department:</strong> {{ selectedDrive.eligible_department }}</p>
      <p><strong>Created At:</strong> {{ selectedDrive.created_at }}</p>
      <p><strong>Application Deadline:</strong> {{ selectedDrive.deadline }}</p>
      <button @click="applyDrive(selectedDrive.id)">
        Apply
      </button>
      <br>
      <div>
        <input type="file" accept=".pdf" @change="selectResume">
        <button @click="uploadResume">
          Upload Resume
        </button>
      </div>
      <button @click="goBack">
        Go Back
      </button>

    </div>

  </div>
</template>

<script>
import axios from 'axios'

export default {
  name: 'StudentDrive',

  data() {
    return {
      company: {},
      drives: [],
      selectedDrive: null,
      resume: null,
    }
  },

  methods: {
    async fetchCompanyDetails() {
      const token = localStorage.getItem('token')
      const company_id = this.$route.params.id

      const res = await axios.get(
        `http://localhost:5000/api/student/viewdrive/${company_id}`,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      )

      this.drives = res.data
    },

    viewDrive(drive) {
      this.selectedDrive = drive
    },
    async applyDrive(id) {
      try {
        const token = localStorage.getItem('token')

        await axios.post(`http://localhost:5000/api/student/apply/${id}`,
          {},
          {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          }
        )

        alert('Successfully applied to the drive')
        this.selectedDrive = null   //go back to parent 

      } catch (error) {
        console.error('Error applying to drive:', error)
        alert(error.response.data.message)
      }
    },
    selectResume(event) {
      this.resume = event.target.files[0]
    },
    async uploadResume() {
      const token = localStorage.getItem('token')

      const formData = new FormData()
      formData.append('resume', this.resume)

      await axios.post(
        'http://localhost:5000/api/student/resume',
        formData,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      )

      alert('Resume uploaded successfully')
    },

    goBack() {
      this.selectedDrive = null
    },

    goToDashboard() {
      this.$router.push('/student')
    },
  },
  mounted() {
    this.fetchCompanyDetails()
  },
}
</script>